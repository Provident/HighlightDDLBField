<?php
$mod_strings['HighLightfield'] = 'Highlight field';
$mod_strings['LBL_HIGHTLIGHTFIELD_FORMAT_HELP'] = '';

$mod_strings['LBL_HIGHTLIGHTFIELD_TEXT_COLOR'] = 'Text Color';
$mod_strings['LBL_HIGHTLIGHTFIELD_COLOR'] = 'Value Colors';